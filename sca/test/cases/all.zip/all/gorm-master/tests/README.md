# Test Guide

```bash
cd tests
# prepare test databases
docker-compose up

# run all tests
./tests_all.sh
```
