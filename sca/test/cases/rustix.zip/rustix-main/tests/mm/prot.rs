#[test]
fn test_prot_flags() {
    assert_eq!(libc::PROT_NONE, 0);
}
