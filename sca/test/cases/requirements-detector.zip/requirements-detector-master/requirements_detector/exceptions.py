class RequirementsNotFound(Exception):
    pass


class CouldNotParseRequirements(Exception):
    pass
