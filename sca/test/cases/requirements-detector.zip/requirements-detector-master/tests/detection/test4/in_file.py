from distutils.core import setup

_install_requires = ["Django==1.5.0", "django-gubbins==1.1.2"]

setup(name="prospector-test-2", version="0.0.1", install_requires=_install_requires)
