from distutils.core import setup

setup(name="prospector-test-1", version="0.0.1", requires=["Django==1.5.0", "django-gubbins==1.1.2"])
