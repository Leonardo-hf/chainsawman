package com.example.gephi_web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GephiWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(GephiWebApplication.class, args);
    }

}
