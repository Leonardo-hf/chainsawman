package com.example.gephi_web.vo;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class GexfVO {
    String name;
    // TODO 可能返回的是文件而不是路径
    String gexf;
}
